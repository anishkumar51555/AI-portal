export function execute() {
  return 'ok';
}
