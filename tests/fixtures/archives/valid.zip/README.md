# Fixture Skill

A valid component used in tests.
